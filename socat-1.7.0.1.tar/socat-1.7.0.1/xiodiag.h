/* source: xiodiag.h */
/* Copyright Gerhard Rieger 2001 */
/* Published under the GNU General Public License V.2, see file COPYING */

#ifndef __xiodiag_h_included
#define __xiodiag_h_included 1

extern const char *ddirection[];
extern const char *filetypenames[];

#endif /* !defined(__xiodiag_h_included) */
